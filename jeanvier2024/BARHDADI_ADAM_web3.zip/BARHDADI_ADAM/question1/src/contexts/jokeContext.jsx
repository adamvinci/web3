import React, { useState } from 'react';
import { useEffect } from 'react';
import JokeAPI from 'services/joke'
const Context = React.createContext(null);

const ProviderWrapper = ({ children }) => {
  const [jokes, setJokes] = useState([]);

useEffect(()=>{
  JokeAPI.getAll().then((response)=>setJokes(response)).catch(error=>console.warn(error))
},[])

const updateImage = (id,newImage)=>  JokeAPI.updateImage(id,newImage).then(()=> JokeAPI.getAll().then((response)=>setJokes(response)).catch(error=>console.warn(error))).catch(error=>console.warn(error))


const exposedValue = {
    jokes,
    updateImage
  };

  return <Context.Provider value={exposedValue}>{children}</Context.Provider>;
};

export { Context, ProviderWrapper };
