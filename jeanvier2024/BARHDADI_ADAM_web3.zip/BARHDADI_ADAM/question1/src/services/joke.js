import axios from "axios"



const baseUrl = "//localhost:3000/famous-jokes"

const getAll = () => axios.get(baseUrl).then(response => response.data)

const updateImage = (jokeId, newImage) => axios.patch(`${baseUrl}/${jokeId}`, newImage)



const JokeAPI = {
  getAll,
  updateImage

}

export default JokeAPI