const Home = ()=> <p>Page d’accueil des blagues les plus célèbres ! </p>

export default Home