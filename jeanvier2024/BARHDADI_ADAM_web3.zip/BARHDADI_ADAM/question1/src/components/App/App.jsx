import Menu from "components/Menu/Menu"
import Home from "components/Home/Home"
import { Routes, Route } from 'react-router-dom';
import JokeList from "components/Jokes/JokeList";


const App =()=>{

  return (
    <div>
      <Menu />
    <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/famous-jokes" element={<JokeList />} />
        </Routes>

    </div>
  )
}
export default App