import { BrowserRouter as Router } from 'react-router-dom';
import App from 'components/App/App';
import { ProviderWrapper as DataProvider } from 'contexts/jokeContext';



const AppLoader = () => {
  return (
    <DataProvider >
      <Router>
      <App />
    </Router>
    </DataProvider>
  );
};

export default AppLoader;
