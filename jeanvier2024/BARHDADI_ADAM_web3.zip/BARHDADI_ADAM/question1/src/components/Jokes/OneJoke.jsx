import { useState } from 'react';
import { Context as JokeContext } from 'contexts/jokeContext';
import { useContext } from 'react';

const OneJoke  =({joke})=>{
    const [imageUrl,setNewUrl] = useState(joke.imageUrl)
    const { updateImage } = useContext(JokeContext);

    return (
        <div>
            <p>{joke.name}</p>
            <p>{joke.joke}</p>
           <div> <input type="text" value={imageUrl} onChange={e=>setNewUrl(e.target.value)} />
            <button onClick={()=>updateImage(joke.id,{imageUrl})}>Mettre a jour l'image</button>
            </div>
            <img style={{width:'200px',height:'200px'}} src={joke.imageUrl}></img>
       
        </div>
    )
}

export default OneJoke