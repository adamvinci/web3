import { Context as JokeContext } from 'contexts/jokeContext';
import { useContext } from 'react';
import OneJoke from 'components/Jokes/OneJoke';

const JokeList  = ()=>{
    const { jokes } = useContext(JokeContext);

    return(
        <div>
            <h1>Manage Jokes</h1>
            {jokes.map((joke)=><OneJoke key={joke.id} {...{joke}}/>)}
        </div>
    )

}
export default JokeList