class NotFoundError extends Error { }

module.exports = exports = NotFoundError