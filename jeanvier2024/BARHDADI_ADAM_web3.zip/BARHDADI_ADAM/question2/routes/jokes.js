const router = require('express').Router()
const Joke  =require('../models/jokes')
const Comment  =require('../models/comments')
const NotFoundError = require('../utils/NotFoundError')


// Find all
router.get("/", (req, res, next) => {
    Joke.find({})
      .then(jokes => res.json(jokes))
      .catch(err => next(err))
  })

  
  // Insert one
router.post("/:id", (req, res, next) => {
    const body = req.body
    // Check body
    const errorMessages = []
    if (!body.comment ) errorMessages.push("comment must be present")
    if (!body.username) errorMessages.push("username must be present")
    if(body.comment && body.comment.length <=5) errorMessages.push("comment must be > 5")
    if(body.username && body.username.length <=3) errorMessages.push("username must be > 3")

    if (errorMessages.length > 0) {
      res.status(422).json({ errorMessages })
      return
    }
    Joke.findById(req.params.id).then(joke => {
        if (joke) {
            Comment.find({ username: body.username, joke: joke.id }).then((comments) => {
                if (comments.length > 0) {
                    errorMessages.push("this user already gave a comment to this joke")
                    res.status(409).json({ errorMessages })
                } else {
                    const comment = new Comment({username:body.username,comment:body.comment,joke:req.params.id}) 
                    comment.save().then(result => {   
                      console.log(result)
                        joke.comments = [...joke.comments,{username:result.username,comment:result.comment}]
                        joke.save().catch(err=>next(err))             
                        res.json({username:result.username,comment:result.comment,joke:result.joke})
                    }).catch(err => next(err))
                }
            })
        } else {
          throw new NotFoundError()
        }
      }).catch(err => next(err))
    
    
    
  })
  
  

module.exports = router